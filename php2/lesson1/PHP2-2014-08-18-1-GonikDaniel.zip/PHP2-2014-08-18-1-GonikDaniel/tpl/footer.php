    <footer class="footer">
        Made with &#x2661; in ШП! &copy; 
    </footer>
</body>
</html>