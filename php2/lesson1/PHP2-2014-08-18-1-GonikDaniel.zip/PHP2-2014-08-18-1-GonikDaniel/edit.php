<!-- edit.php – изменений одной записи -->
<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once 'config.php';

$id = intval($_GET['id']);
//подготовим поля для дальнейшего автоматического обновления статей через, например, редактор
$new_title = mysqli_real_escape_string($dbc, trim('Анормальный скачок функции: теорема или подынтегральное выражение?')); 
$new_content = mysqli_real_escape_string($dbc, trim('То, что написано на этой странице неправда! Следовательно: нормальное распределение тривиально. Степенной ряд оправдывает косвенный экстремум функции, как и предполагалось. Функция выпуклая кверху привлекает интеграл Дирихле.
Теорема, исключая очевидный случай, концентрирует метод последовательных приближений. Ряд Тейлора, как следует из вышесказанного, притягивает параллельный неопределенный интеграл, что несомненно приведет нас к истине. Функция выпуклая кверху привлекает полином.
Интеграл Пуассона переворачивает экспериментальный функциональный анализ. Следствие: бином Ньютона нейтрализует интеграл от функции комплексной переменной. Экстремум функции выведен. К тому же дивергенция векторного поля позитивно искажает абсолютно сходящийся ряд.'));

//проверяем на дублирование
$query = "SELECT * FROM `articles` WHERE `id` = '$id'";
$data = mysqli_query($dbc, $query) or trigger_error(mysql_error().$query);
if (mysqli_num_rows($data) === 1) {
	$row = mysqli_fetch_array($data);
		echo '<p>Вы уверены, что хотите заменить данные этой статьи?</p>';
		echo '<p><strong>Заголовок: </strong>' . $row['title'] . '<br /><strong>Содержание: </strong>' . 
		$row['content'] . '<br /><strong>Дата публикации: </strong>' . $row['posted_date'] . '</p>';
		echo '<form method="post" action="">';
		echo '<input type="radio" name="confirm" value="yes" />Да';
		echo '<input type="radio" name="confirm" value="no" checked="checked" />Нет<br />';
		echo '<input type="submit" name="submit" value="Обновить" />';
		echo '<input type="hidden" name="id" value="'. $id .'" />';
		echo '<input type="hidden" name="title" value="'. $row['title'] .'" />';
		echo '<input type="hidden" name="posted_date" value="'. $row['posted_date'] .'" />';
		echo '</form>';

		echo '<p>Данные новой статьи:</p>';
		echo '<p>' . $new_title . '</p>';
		echo '<p>' . $new_content . '</p>';
}


if (isset($_POST['submit'])) {
	if ('' !== $new_title && '' !== $new_content && $_POST['confirm'] == 'yes') {
		$query = "UPDATE `articles` SET `title`='$new_title', `content`='$new_content' WHERE `id`='$id' LIMIT 1";
		mysqli_query($dbc, $query) or trigger_error(mysql_error().$query);
		echo '<p style="color:red; font-size:3em;">Статья успешно обновлена</p>';	
	} else {
		echo '<p>Вы не заполнили поля заголовка и/или контента.</p>';
	}
}

mysqli_close($dbc);

echo '<p><a href="admin.php">&lt;&lt; Назад к списку статей</a></p>';
?>