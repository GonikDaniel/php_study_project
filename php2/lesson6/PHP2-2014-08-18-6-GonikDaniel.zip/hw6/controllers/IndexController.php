<?php
  class IndexController {
   public function __construct() {
    echo "Мы в контроллере INDEX";
   }
  }
?>