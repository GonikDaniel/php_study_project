<?php 

class ArticlesModel
	extends AbstractModel
{
	static public $table = 'articles';
}

?>