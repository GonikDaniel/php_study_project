<div class="article">
	<h2><?php echo $this->item['title']; ?></h2>
	<p><?php echo $this->item['content']; ?></p>
	<p><?php echo $this->item['posted_date']; ?></p>
</div>