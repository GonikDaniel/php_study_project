<div id="registr_form">
    <form method="post" action="">
        <table>
            <tr>
                <td><label>Имя:</label></td>
                <td><input type="text" name="username"></td>
            </tr>
            <tr>
                <td><label>Пароль:</label></td>
                <td><input type="password" name="password"></td>
            </tr>
            <tr>
                <td><label>Запомнить?:</label></td>
                <td><input type="checkbox" name="auto"></td>
            </tr>
            <tr>
                <td></td>
                <td><input type="submit" value="login"></td>
            </tr>
        </table>  
    </form>
    <p>Еще не зарегистрированы? Тогда Вам <a href="?ctrl=User&action=signUp">сюда</a>.</p>
</div>
